package com.tomekl007.chapter_1.profilesconfig;

public interface DataSourceConfig {
    public void setup();
}