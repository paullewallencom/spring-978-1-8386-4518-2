package com.tomekl007.salary.details.api;

public interface SalaryDetails {
  String getInfoAboutSalary(String cityName);
}
