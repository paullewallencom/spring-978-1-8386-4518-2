package com.tomekl007.salary.api;

import com.tomekl007.chapter_2.domain.Salary;

public interface SalaryService {
    boolean pay(Salary salary);
}
