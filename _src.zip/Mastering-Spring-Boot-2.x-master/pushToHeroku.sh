#!/usr/bin/env bash
git push -f heroku HEAD:master